from django.urls import path
from . import views
urlpatterns = [
   path("",views.task_list,name='task_list'),
   path("create",views.create_task,name='create'),
   path('update_task/<int:pk>/', views.update, name='update_task'),
   path('delete_task/<int:pk>/', views.delete, name='delete_task'), 
  ]