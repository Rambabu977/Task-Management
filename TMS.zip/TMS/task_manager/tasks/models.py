from django.db import models

# Create your models here.
class Task(models.Model):
     titel= models.CharField(max_length=200)
     description = models.TextField()
     create_at = models.DateTimeField(auto_now_add=True)
     update_at = models.DateTimeField(auto_now= True)
     
     def __self__(self):
          return self.titel